package com.course.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Student {
    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_post"
    )
    @SequenceGenerator(
            name = "seq_post",
            allocationSize = 5,
            initialValue = 10000
    )
    private int id;
    private String firstName;
    private String lastName;
    private String dob;
    private String password;
    private String courseCodes;
    private String role;
    private double total;

}
