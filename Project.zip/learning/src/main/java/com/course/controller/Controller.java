package com.course.controller;

import com.course.dto.Parameters;
import com.course.dto.ResponseMessage;
import com.course.dto.StudentDto;
import com.course.dto.UserParam;
import com.course.repo.StudentRepo;
import com.course.service.RoleService;
import com.course.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Response;
import java.util.List;

@CrossOrigin
@RestController
public class Controller {

    @Autowired
    private StudentService service;

    @Autowired
    private RoleService roleService;


    @PostMapping("/permitAll")
    public String home(){
        return "permit for all";
    }

    @GetMapping("/user")
    public String user(){
        return "User";
    }

    @PostMapping("/user/addUser")
    public ResponseEntity<StudentDto> addUser(@RequestBody StudentDto param){
        StudentDto std = service.addUser(param);
        UserParam roles = new UserParam();
        roles.setUserName(std.getId()+"");
        roles.setId(std.getId()-10000);
        roles.setPassword(std.getPassword());
        roles.setRole(param.getRole().toUpperCase());
        roleService.addUser(roles);
        return new ResponseEntity<>(std, HttpStatus.OK);
    }

    @PostMapping("/user/login")
    public ResponseEntity<ResponseMessage> login(@RequestBody StudentDto std){
        StudentDto res = service.login(std.getId(),std.getPassword());
        if(res == null){
            return new ResponseEntity<>(new ResponseMessage("Username/Password invalid."),HttpStatus.NOT_FOUND);
        }else{
            return new ResponseEntity<>(new ResponseMessage(""+res.getId()),HttpStatus.OK);
        }
    }

    @GetMapping("/data")
    public ResponseEntity<StudentDto> getData(){
        return new ResponseEntity<>(new StudentDto(),HttpStatus.OK);
    }

    @PostMapping("/user/addCourse")
    public ResponseEntity<ResponseMessage> addCourses(@RequestBody Parameters param){
        int update = service.addCourses(param.getId(),param.getCourseCodes());
        if(update == 1){
            return new ResponseEntity<>(new ResponseMessage("course updated successfully"),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(new ResponseMessage("Student Id Invalid."),HttpStatus.OK);

        }

    }

    @GetMapping("/admin/getAll")
    public ResponseEntity<List<StudentDto>> getAllUsers(){
        return new ResponseEntity<>(service.getUsers(),HttpStatus.OK);
    }

    @GetMapping("/admin/findById")
    public ResponseEntity<StudentDto> findById(@RequestBody StudentDto std){
        return new ResponseEntity<>(service.findById(std.getId()),HttpStatus.OK);
    }

    @GetMapping("/user/getUserDetails")
    public ResponseEntity<StudentDto> getUserDetails(@RequestBody StudentDto std){
        return new ResponseEntity<>(service.findById(std.getId()),HttpStatus.OK);
    }
}
