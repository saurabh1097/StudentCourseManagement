//package com.course.controller;
//
//import com.course.entity.Param;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//public class HomeController {
//    @GetMapping("/user/home")
//    public String Home(){
////        System.out.println(str + " hello");
//        return "this is home";
//    }
//
//    @PostMapping("/user/hel")
//    public String HomePost(){
////        System.out.println(str + " hello");
//        return "this is home";
//    }
//    @GetMapping("/admin")
//    public String admin(){
//        return "this is for admin";
//    }
//
//    @PostMapping("/admin/param")
//    public String adminPost(@RequestBody Param p){
//        return "this is for admin"+p;
//    }
//}
