package com.course.controller;

import com.course.dto.UserDto;
import com.course.dto.UserParam;
import com.course.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/admin")
public class UserController {
    @Autowired
    private RoleService service;

    @PostMapping("/addRole")
    public ResponseEntity<UserDto> home(@RequestBody UserParam param){
        return new ResponseEntity<>(service.addUser(param), HttpStatus.OK);
    }



    @GetMapping("/user")
    public ResponseEntity<UserDto> user(){
        return new ResponseEntity<>(new UserDto(), HttpStatus.OK);
    }
}
