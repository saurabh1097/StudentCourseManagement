package com.course.service;

import com.course.dto.StudentDto;
import com.course.entity.Student;
import com.course.repo.StudentRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepo repo;

    @Autowired
    private ModelMapper mapper;

    public StudentDto addUser(StudentDto param) {
        double total = param.getCourseCodes().length() * 600;
        double discount = total * 0.10;
        System.out.println(param.toString());
        System.out.println("total :"+total+" dis:"+discount);

        if(param.getCourseCodes().length() > 3){
            param.setTotal(total - discount);
        }else {
            param.setTotal(total);
        }
        System.out.println(mapper.map(param, StudentDto.class));
        StudentDto res = mapper.map(repo.save(mapper.map(param, Student.class)), StudentDto.class);
        return res;
    }

    public List<StudentDto> getUsers() {
        List<Student> studentList = repo.findAll();
        List<StudentDto> list = studentList.stream().map(v -> mapper.map(v, StudentDto.class)).collect(Collectors.toList());
        return list;
    }

    public StudentDto findById(Integer id) {
        Optional<Student> s = repo.findById(id);
        StudentDto res = new StudentDto();
        if (s.isPresent()) {
            res = mapper.map(s, StudentDto.class);
            double total = res.getCourseCodes().length() * 600;
            double discount = total * 0.10;
            if (res.getCourseCodes().length() > 3) {
                res.setTotal(total-discount);
            } else {
                res.setTotal(total);
            }
        }
        return res;
    }

    public int addCourses(Integer id, String course) {
        System.out.println(id + "  " + course + " " + repo.existsById(id));
        if (repo.existsById(id)) {
            Student s = repo.findById(id).get();
            s.setCourseCodes(course);
            repo.save(s);
            return 1;
        } else {
            return 0;
        }
    }

    @Override
    public StudentDto login(int id, String password) {
        if(repo.existsById(id)){
            StudentDto s = mapper.map(repo.findById(id),StudentDto.class);
            if(s.getPassword().equals(password)){
                return s;
            }else{
                return null;
            }
        }else {
            return null;
        }

    }
}
