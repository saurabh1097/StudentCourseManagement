package com.course.service;


import com.course.dto.UserDto;
import com.course.dto.UserParam;

import java.util.List;

public interface RoleService {
    public UserDto addUser(UserParam user);
    public List<UserDto> getAll();
    public UserDto getById(String userName);
}
