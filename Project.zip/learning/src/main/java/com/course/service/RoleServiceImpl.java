package com.course.service;

import com.course.dto.UserDto;
import com.course.dto.UserParam;
import com.course.entity.User;
import com.course.repo.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService{
    @Autowired
    private UserRepository repo;

    @Autowired
    private ModelMapper mapper;

    @Override
    public UserDto addUser(UserParam user) {
        BCryptPasswordEncoder enco = new BCryptPasswordEncoder();
        user.setPassword(enco.encode(user.getPassword()));
        return mapper.map(repo.save(mapper.map(user, User.class)), UserDto.class);
    }

    @Override
    public List<UserDto> getAll() {
        return null;
    }

    @Override
    public UserDto getById(String userName) {
        return null;
    }
}
