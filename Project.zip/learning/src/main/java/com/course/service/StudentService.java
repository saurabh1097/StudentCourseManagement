package com.course.service;

import com.course.dto.StudentDto;

import java.util.List;

public interface StudentService {

    public StudentDto addUser(StudentDto param);
    public List<StudentDto> getUsers();
    public StudentDto findById(Integer id);
    public int addCourses(Integer id,String course);

    public StudentDto login(int id, String password);
}
