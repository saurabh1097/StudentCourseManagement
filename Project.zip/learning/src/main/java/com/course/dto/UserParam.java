package com.course.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class UserParam {
    private int id;
    private String userName;
    private String password;
    private String role;
}
