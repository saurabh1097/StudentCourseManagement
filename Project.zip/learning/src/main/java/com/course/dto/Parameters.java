package com.course.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Parameters {
    private int id;
    private String firstName;
    private String lastName;
    private String dob;
    private String password;
    private String courseCodes;
    private String role;
}
