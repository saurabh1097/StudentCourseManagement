package com.course.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class UserDto {
    private int id;
    private String username;
    private String password;
    private String role;
}
