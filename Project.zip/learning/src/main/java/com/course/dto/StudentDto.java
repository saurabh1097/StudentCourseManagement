package com.course.dto;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class StudentDto {
    private int id;
    private String firstName;
    private String lastName;
    private String dob;
    private String password;
    private String courseCodes;
    private Double total;
    private String role;
}
